import pandas as pd
import numpy as np
import json 
from sklearn.tree import DecisionTreeClassifier 
import seaborn as sns
import pickle
import streamlit as st
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
import joblib

# Load the trained pipeline
pipeline = joblib.load('pipeline (1).pkl')



#Function to Predict
def predict(reason_end, short_pause, No_pause, reason_start, Shuffle, context_type, bounciness, us_pop, acousticness, acoustic_vector_3, acoustic_vector_0, session_length, loudness, acoustic_vector_2):
    
    if No_pause=="True":
        flag=True
    else :
        flag=False
    # create a 2D array from the input values
    print(reason_end == "backbtn")
    print(reason_start == "backbtn")
    print(int(No_pause=="True"))
    X = np.array([[int(reason_end == "backbtn"), int(reason_end == "fwdbtn"), flag, 
                   int(reason_start == "fwdbtn"), int(reason_end == "clickrow"), 
                   int(reason_start == "trackerror"), bounciness, int(reason_start == "backbtn"), 
                   int(reason_end == "remote"), int(Shuffle=="True"), int(context_type == "User Collection"), 
                   int(reason_start == "clickrow"), int(reason_end == "endplay"), session_length, 
                   acoustic_vector_0, us_pop, acoustic_vector_3, loudness, acousticness, acoustic_vector_2]])
    # make the prediction using the loaded model
    prediction = pipeline.predict(X)[0]
    if prediction:
        st.success("The user is likely to listen to the song.")
    else:
        st.error("The user is likely to skip the song.")



#Streamlit Code
st.title('Spotify Song Skip Prediction')
st.image("""https://storage.googleapis.com/pr-newsroom-wp/1/2018/11/Spotify_Logo_RGB_Green.png""")
st.header('Enter the characteristics of the Song:')
reason_end = st.selectbox('Reason to end track:', ["None","backbtn", "fwdbtn", "clickrow", "remote", "endplay"])
short_pause = st.selectbox('Short Pause before play:', ["True", "False"])
No_pause = st.selectbox('No Pause before play:', ["True", "False"])
Shuffle = st.selectbox('Shuffle:', ["True", "False"])
reason_start = st.selectbox('Reason to start track:', ["None","backbtn", "fwdbtn", "clickrow","trackerror"])
context_type = st.selectbox('Context Type:', ["None","User Collection", "editorial", "radio","charts","catalog"])
bounciness = st.number_input('Bounciness:', min_value=0.0, max_value=0.9,step=0.1)
us_pop = st.number_input('Us_popularity_estimate:',min_value=90.0, max_value=100.0)
acousticness = st.number_input("acousticness:",  min_value=0.0, max_value=0.9,step=0.1)
acoustic_vector_3 = st.number_input("acoustic_vector_3:", step=0.1)
acoustic_vector_0 = st.number_input("acoustic_vector_0:", step=0.1)
acoustic_vector_2 = st.number_input("acoustic_vector_2:", step=0.1)
session_length = st.number_input('session_length:', min_value=10.0, max_value=20.0,step=1.0)
loudness = st.number_input('loudness:', min_value=-60.0, max_value=1.64,step=0.1)
if st.button('Predict '):
    predict(reason_end, short_pause, No_pause, reason_start,Shuffle, context_type,bounciness,us_pop,acousticness,acoustic_vector_3,acoustic_vector_0,session_length,loudness,acoustic_vector_2)
    
    